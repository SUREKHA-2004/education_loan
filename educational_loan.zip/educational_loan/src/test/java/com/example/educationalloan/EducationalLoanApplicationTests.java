package com.example.educationalloan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EducationalLoanApplicationTests {

	@Test
	void contextLoads() {
	}

}
