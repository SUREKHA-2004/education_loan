package com.example.educationalloan.controller;

import java.util.List;
//import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.educationalloan.model.LoanApplicationModel;
import com.example.educationalloan.model.UserModel;
import com.example.educationalloan.service.EducationalLoanService;

@RestController
public class EducationalLoanController {
	@Autowired
	EducationalLoanService a;
	

	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Student created successfully"),

			@ApiResponse(responseCode = "400", description = "Student is invalid"),

			@ApiResponse(responseCode = "401", description = "Invalid credentials") })

	@ResponseStatus(HttpStatus.CREATED)
	@GetMapping(value="/getloanid")
	public List<LoanApplicationModel> getAllLoan()
	{
		return a.getAllvalues();
		
	}
	@PostMapping(value="/postloanid")
	public LoanApplicationModel saveLoan(@RequestBody LoanApplicationModel b) 
	{
		return a.savevalues(b);
	}
	@PutMapping(value="/updateloan")
	public LoanApplicationModel  updateLoan(@RequestBody LoanApplicationModel p)
	{
		return a.updateloan(p);
	}
	
	@DeleteMapping("/deleid/{lid}")
	public String deleteLoan(@PathVariable("lid") int loanId)
	{
		 return a.deletevalues(loanId);
	}
	@GetMapping(value="/getid1/{lid}")
	public LoanApplicationModel getLoan(@PathVariable("lid") int loanId)
	{
		return a.getvalues(loanId);
	}
//	//user
	
	@GetMapping(value="/getuserid")
	public List<UserModel> getAllnew()
	{
		return a.getAlluser();
		
	}
	@PostMapping(value="/postuserid")
	public UserModel savenew(@RequestBody UserModel y) 
	{
		return a.saveData(y);
	}
	@DeleteMapping("/deleuserid/{id}")
	public  String deletenew(@PathVariable("id") int Id)
	{
		 return a.deleteuser(Id);
	}
	@PutMapping(value="/updateuser")
	public UserModel  updateUser(@RequestBody UserModel p)
	{
		return a.updateuser(p);
	}
}
